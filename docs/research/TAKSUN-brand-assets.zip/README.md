# TAKSUN / 9999 in 1 BRICK GAME — reconstructed logos

Source: supplied close-up photo of blue TAKSUN handheld. Digitally traced from the photo. Both logos are drawn with real vector paths rather than embedded bitmaps.

- `taksun-upper-logo.svg` / `.png`: illustration of the bow-wielding child and original 9999 in 1 / BRICK GAME inscriptions, blue skin filled to stand out on any backdrop.
- `taksun-upper-logo-stencil.svg` / `.png`: closer to original pad printing, where blue plastic is visible through unprinted areas. Best for applying to a blue device model.
- `taksun-wordmark.svg` / `.png`: separate gold TAKSUN inscription, transparent.
- `taksun-wordmark-plaque.svg` / `.png`: gold TAKSUN on recessed blue plastic nameplate.
- `preview-on-blue.jpg`: examples on approximate shell blue.

Suggested paths in ApolloBrickGames:
`public/brand/taksun-upper-logo.svg`, `public/brand/taksun-wordmark.svg`.

Details: contours follow the supplied photograph. Original was scratched and shot at a slight angle; tiny engravings and colored areas are reconstructed and thus not guaranteed pixel-perfect to pristine factory artwork. All SVG files remain scalable and use self-contained vector paths.
