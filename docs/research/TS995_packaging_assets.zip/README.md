# TS-995 Classics Game Machine | packaging restoration

Reconstructed from user-supplied photographs, using the attached 'ТАНК 168 В 1' example as the visual template for the unfolded layout.

## Exports
- `TS995_box_dieline.svg` — self-contained SVG with embedded photo artwork; rear, sides, top and bottom text remain editable.
- `TS995_box_dieline_2x.png` — transparent full layout, 4600×3240 px.
- `TS995_box_dieline_preview.png` — lightweight transparent 2300×1620 preview.
- `TS995_front_panel.png`, `TS995_back_panel.png`, side panels — panel-sized site assets.
- `TS995_front_photo_rectified.jpg`, `TS995_back_photo_rectified.jpg` — perspective-corrected photographic originals.
- `TS995_paper.png` — off-white paper texture used in the SVG.

## Fidelity and limits
- The complex TS-995 front illustration and console image are retained directly from a perspective-corrected photograph, rather than fabricated or redrawn. This remains a bitmap embedded inside otherwise editable SVG. Original print wear may still show.
- Back instructions have been typed, conserving odd spelling and grammar as printed (e.g. `Russia brick`, `get ride of them`, `bunching simpleton`, `dragon robbing ball`).
- UPC-A `199907269952` was restored and has a valid check digit.
- Side text was visible on **one side only** in the references; this reconstruction repeats it on the second side. This is an assumption, not a confirmed reproduction of the unseen face.
- Upper/lower printed flaps are composed from the observed `TS-995 / CLASSICS GAME MACHINE` edge and repeated as in the ТАНК template; the unseen flap's print is not independently documented.
- Fold and die cut measurements are **illustrative, not manufacturing verified**. Do not use them to mass-print die cut boxes without measuring an unfolded original.
- Fonts: SVG references a Times-like system face (`Liberation Serif` / `Times New Roman`). Convert text to outlines for exact cross-platform typography before offset printing.
- Intended for archival/catalogue and web project use, not an asserted factory blueprint.
